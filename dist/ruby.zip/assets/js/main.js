(function () {
    pagination(true);
})();
